#ifndef __MANDELBROTSET_H__
#define __MANDELBROTSET_H__

#include"defs.h"
#include<math.h>
#include<complex.h>
#include"image_utils.h"

int MAX_ITER = 100;
float complex mul(float complex a)
{
    float v=crealf(a)*crealf(a)-cimagf(a)*cimagf(a);
    float u=crealf(a)*cimagf(a)+crealf(a)*cimagf(a);
    float complex result=v+u*I;
    return result;
}
float  mandelbrot(float complex c)
{
   float complex z=0;
   int n = 0;
    while (cabsf(z) <= 2 && n < MAX_ITER)
    {
        z = mul(z) + c;
        n += 1;
    }
    if(n == MAX_ITER)
        return MAX_ITER;
    return n + 1 - log(log2(cabsf(z)));
}
void UpdateImageData(ImageState* state)
{
    state->bmFileData.bmHeader.colorIdx[0].r=0;
    state->bmFileData.bmHeader.colorIdx[0].g=0;
    state->bmFileData.bmHeader.colorIdx[0].b=0;
    state->bmFileData.bmHeader.colorIdx[1].r=2;
    state->bmFileData.bmHeader.colorIdx[1].g=2;
    state->bmFileData.bmHeader.colorIdx[1].b=2;
    state->bmFileData.bmHeader.colorIdx[2].r=4;
    state->bmFileData.bmHeader.colorIdx[2].g=4;
    state->bmFileData.bmHeader.colorIdx[2].b=4;
    state->bmFileData.bmHeader.colorIdx[3].r=6;
    state->bmFileData.bmHeader.colorIdx[3].g=6;
    state->bmFileData.bmHeader.colorIdx[3].b=6;
    state->bmFileData.bmHeader.colorIdx[4].r=8;
    state->bmFileData.bmHeader.colorIdx[4].g=8;
    state->bmFileData.bmHeader.colorIdx[4].b=8;
    state->bmFileData.bmHeader.colorIdx[5].r=10;
    state->bmFileData.bmHeader.colorIdx[5].g=10;
    state->bmFileData.bmHeader.colorIdx[5].b=10;
    state->bmFileData.bmHeader.colorIdx[6].r=12;
    state->bmFileData.bmHeader.colorIdx[6].g=12;
    state->bmFileData.bmHeader.colorIdx[6].b=12;
    state->bmFileData.bmHeader.colorIdx[7].r=14;
    state->bmFileData.bmHeader.colorIdx[7].g=14;
    state->bmFileData.bmHeader.colorIdx[7].b=14;
    state->bmFileData.bmHeader.colorIdx[8].r=16;
    state->bmFileData.bmHeader.colorIdx[8].g=16;
    state->bmFileData.bmHeader.colorIdx[8].b=16;
    state->bmFileData.bmHeader.colorIdx[9].r=18;
    state->bmFileData.bmHeader.colorIdx[9].g=18;
    state->bmFileData.bmHeader.colorIdx[9].b=18;
    state->bmFileData.bmHeader.colorIdx[10].r=20;
    state->bmFileData.bmHeader.colorIdx[10].g=20;
    state->bmFileData.bmHeader.colorIdx[10].b=20;
    state->bmFileData.bmHeader.colorIdx[11].r=22;
    state->bmFileData.bmHeader.colorIdx[11].g=22;
    state->bmFileData.bmHeader.colorIdx[11].b=22;
    state->bmFileData.bmHeader.colorIdx[12].r=24;
    state->bmFileData.bmHeader.colorIdx[12].g=24;
    state->bmFileData.bmHeader.colorIdx[12].b=24;
    state->bmFileData.bmHeader.colorIdx[13].r=26;
    state->bmFileData.bmHeader.colorIdx[13].g=26;
    state->bmFileData.bmHeader.colorIdx[13].b=26;
    state->bmFileData.bmHeader.colorIdx[14].r=28;
    state->bmFileData.bmHeader.colorIdx[14].g=28;
    state->bmFileData.bmHeader.colorIdx[14].b=28;
    state->bmFileData.bmHeader.colorIdx[15].r=30;
    state->bmFileData.bmHeader.colorIdx[15].g=30;
    state->bmFileData.bmHeader.colorIdx[15].b=30;
    state->bmFileData.bmHeader.colorIdx[16].r=32;
    state->bmFileData.bmHeader.colorIdx[16].g=32;
    state->bmFileData.bmHeader.colorIdx[16].b=32;
    state->bmFileData.bmHeader.colorIdx[17].r=34;
    state->bmFileData.bmHeader.colorIdx[17].g=34;
    state->bmFileData.bmHeader.colorIdx[17].b=34;
    state->bmFileData.bmHeader.colorIdx[18].r=36;
    state->bmFileData.bmHeader.colorIdx[18].g=36;
    state->bmFileData.bmHeader.colorIdx[18].b=36;
    state->bmFileData.bmHeader.colorIdx[19].r=38;
    state->bmFileData.bmHeader.colorIdx[19].g=38;
    state->bmFileData.bmHeader.colorIdx[19].b=38;
    state->bmFileData.bmHeader.colorIdx[20].r=38;
    state->bmFileData.bmHeader.colorIdx[20].g=38;
    state->bmFileData.bmHeader.colorIdx[20].b=38;
    state->bmFileData.bmHeader.colorIdx[21].r=40;
    state->bmFileData.bmHeader.colorIdx[21].g=40;
    state->bmFileData.bmHeader.colorIdx[21].b=40;
    state->bmFileData.bmHeader.colorIdx[22].r=43;
    state->bmFileData.bmHeader.colorIdx[22].g=43;
    state->bmFileData.bmHeader.colorIdx[22].b=43;
    state->bmFileData.bmHeader.colorIdx[23].r=60;
    state->bmFileData.bmHeader.colorIdx[23].g=60;
    state->bmFileData.bmHeader.colorIdx[23].b=60;
    state->bmFileData.bmHeader.colorIdx[24].r=70;
    state->bmFileData.bmHeader.colorIdx[24].g=70;
    state->bmFileData.bmHeader.colorIdx[24].b=70;
    state->bmFileData.bmHeader.colorIdx[25].r=80;
    state->bmFileData.bmHeader.colorIdx[25].g=80;
    state->bmFileData.bmHeader.colorIdx[25].b=80;
    state->bmFileData.bmHeader.colorIdx[26].r=90;
    state->bmFileData.bmHeader.colorIdx[26].g=90;
    state->bmFileData.bmHeader.colorIdx[26].b=90;


    state->bmFileData.bmHeader.colorIdx[27].r=51;
    state->bmFileData.bmHeader.colorIdx[27].g=250;
    state->bmFileData.bmHeader.colorIdx[27].b=250;

    state->bmFileData.bmHeader.colorIdx[28].r=143;
    state->bmFileData.bmHeader.colorIdx[28].g=255;
    state->bmFileData.bmHeader.colorIdx[28].b=255;

    state->bmFileData.bmHeader.colorIdx[29].r=160;
    state->bmFileData.bmHeader.colorIdx[29].g=250;
    state->bmFileData.bmHeader.colorIdx[29].b=255;

    state->bmFileData.bmHeader.colorIdx[30].r=220;
    state->bmFileData.bmHeader.colorIdx[30].g=248;
    state->bmFileData.bmHeader.colorIdx[30].b=255;

    state->bmFileData.bmHeader.colorIdx[31].r=208;
    state->bmFileData.bmHeader.colorIdx[31].g=253;
    state->bmFileData.bmHeader.colorIdx[31].b=255;

    state->bmFileData.bmHeader.colorIdx[32].r=240;
    state->bmFileData.bmHeader.colorIdx[32].g=255;
    state->bmFileData.bmHeader.colorIdx[32].b=255;
    double cr = 3.14/180;
    for(int x=0; x<state->width; x++)
    {
        for(int y=0; y<state->height; y++)
        {
            double nx = state->minx + (x/(state->width/(state->maxx-state->minx)));
            double ny = state->miny + (y/(state->height/(state->maxy-state->miny)));
            double rx = nx * cos(state->angle*cr) + ny * sin(state->angle*cr);
            double ry = -nx * sin(state->angle*cr) + ny * cos(state->angle*cr);
            float complex c = rx+ry*I;
            float m = mandelbrot(c);
            if(1<=m && m<1.1)
            state->bmFileData.bmData[y*state->width+x]= 0;
            else if (1.1<=m && m<1.4)
            state->bmFileData.bmData[y*state->width+x]= 1;
            else if (1.4<=m && m<1.7)
            state->bmFileData.bmData[y*state->width+x]= 2;
            else if (1.7<=m && m<2)
            state->bmFileData.bmData[y*state->width+x]= 3;
            else if (2<=m && m<2.3)
            state->bmFileData.bmData[y*state->width+x]= 4;
            else if (2.3<=m && m<2.6)
            state->bmFileData.bmData[y*state->width+x] = 5;
            else if (2.6<=m && m<2.9)
            state->bmFileData.bmData[y*state->width+x]= 6;
            else if (2.9<=m && m<3.2)
            state->bmFileData.bmData[y*state->width+x]= 7;
            else if (3.2<=m && m<3.5)
            state->bmFileData.bmData[y*state->width+x]= 8;
            else if (3.5<=m && m<3.8)
            state->bmFileData.bmData[y*state->width+x]= 9;
            else if (3.8<=m && m<4.1)
            state->bmFileData.bmData[y*state->width+x]= 10;
            else if(4.1<=m && m<4.4)
            state->bmFileData.bmData[y*state->width+x]= 11;
            else if (4.4<=m && m<4.7)
            state->bmFileData.bmData[y*state->width+x]= 12;
            else if (4.7<=m && m<5)
            state->bmFileData.bmData[y*state->width+x]= 13;
            else if (5<=m && m<5.3)
            state->bmFileData.bmData[y*state->width+x]= 14;
            else if (5.3<=m && m<5.6)
            state->bmFileData.bmData[y*state->width+x]= 15;
            else if (5.6<=m && m<5.9)
            state->bmFileData.bmData[y*state->width+x]= 16;
            else if (5.9<=m && m<6.2)
            state->bmFileData.bmData[y*state->width+x]= 17;
            else if (6.2<=m && m<6.5)
            state->bmFileData.bmData[y*state->width+x] = 18;
            else if (6.5<=m && m<7)
            state->bmFileData.bmData[y*state->width+x] = 19;
            else if (7<=m && m<8)
            state->bmFileData.bmData[y*state->width+x] = 20;
            else if (8<=m && m<9)
            state->bmFileData.bmData[y*state->width+x] = 21;
            else if (9<=m && m<10)
            state->bmFileData.bmData[y*state->width+x] = 22;
            else if (10<=m && m<11)
            state->bmFileData.bmData[y*state->width+x] = 23;
            else if (11<=m && m<12)
            state->bmFileData.bmData[y*state->width+x] = 24;
            else if (12<=m && m<13)
            state->bmFileData.bmData[y*state->width+x] = 25;
            else if (13<=m && m<14)
            state->bmFileData.bmData[y*state->width+x] = 26;
            else if (14<=m && m<15)
            state->bmFileData.bmData[y*state->width+x] = 27;
            else if (15<=m && m<17)
            state->bmFileData.bmData[y*state->width+x] = 28;
            else if (17<=m && m<19)
            state->bmFileData.bmData[y*state->width+x] = 29;
            else if (19<=m && m<21)
            state->bmFileData.bmData[y*state->width+x] = 30;
            else if (21<=m && m<23)
            state->bmFileData.bmData[y*state->width+x] = 31;
            else if (23<=m && m<25)
            state->bmFileData.bmData[y*state->width+x] = 32;
            else if(m>25)
            state->bmFileData.bmData[y*state->width+x] =0;
        }
        }
}

void ChangeCenter(ImageState* state, double newcx, double newcy, int steps)
{
    double a = (newcx - state->cx)/steps;
    double b = (newcy - state->cy)/steps;
    for(int i=0;i<steps; i++)
    {
        state->cx += a;
        state->cy += b;
        state->minx +=a;
        state->maxx +=a;
        state->miny +=b;
        state->maxy +=b;
        UpdateImageData(state);
        WriteBitmapFile(state->image_count++, & state->bmFileData);
    }
}

void ChangeZoom(ImageState* state, double zoom, int steps)
{

    for(int i=0; i<steps; i++)
    {
        double u =(zoom*(state->maxy - state->miny))/(steps*4);
        double v =(zoom*(state->maxx - state->minx))/(steps*4);
        state->minx += v;
        state->maxx -= v;
        state->miny += u;
        state->maxy -= u;
        UpdateImageData(state);
        WriteBitmapFile(state->image_count++, & state->bmFileData);
    }
}

void ChangeRotation(ImageState* state, double angle, int steps)
{
    double angle_step = angle / steps;
    for(int i=0; i<steps; i++)
    {
        state->angle += angle_step;
        UpdateImageData(state);
        WriteBitmapFile(state->image_count++, & state->bmFileData);
    }
}

void Hold(ImageState* state, int steps)
{
    for(int i=0; i<steps; i++)
    {
        UpdateImageData(state);
        WriteBitmapFile(state->image_count++, & state->bmFileData);
    }
}
void ChangeZoomRotation(ImageState* state, double zoom, double angle, int steps)
{
    double angle_step = angle / steps;
    for(int i=0;i<steps; i++)
    {
        double u =(zoom*(state->maxy - state->miny))/(steps*4);
        double v =(zoom*(state->maxx - state->minx))/(steps*4);
        state->minx += v;
        state->maxx -= v;
        state->miny += u;
        state->maxy -= u;
        state->angle += angle_step;
        UpdateImageData(state);
        WriteBitmapFile(state->image_count++, & state->bmFileData);
    }
}
void ChangeZoomout(ImageState* state, double zoom,int steps)
{
    for(int i=0;i<steps; i++)
    {
        double u =(zoom*(state->maxy - state->miny))/(steps*4);
        double v =(zoom*(state->maxx - state->minx))/(steps*4);
        state->minx -= v;
        state->maxx += v;
        state->miny -= u;
        state->maxy += u;
        UpdateImageData(state);
        WriteBitmapFile(state->image_count++, & state->bmFileData);
    }
}
void ChangeZoomrotationout(ImageState* state, double zoom, double angle, int steps)
{
    double angle_step = angle / steps;
    for(int i=0;i<steps; i++)
    {
        double u =(zoom*(state->maxy - state->miny))/(steps*4);
        double v =(zoom*(state->maxx - state->minx))/(steps*4);
        state->minx -= v;
        state->maxx += v;
        state->miny -= u;
        state->maxy += u;
        state->angle += angle_step;
        UpdateImageData(state);
        WriteBitmapFile(state->image_count++, & state->bmFileData);
    }
}

#endif
