
40.times do
  use_synth :growl
  play 70, pan: -1
  sleep 0.1
  play 75, pan: 0
  sleep 0.1
  play 80, pan: 1
  sleep 0.1
end
in_thread do
  30.times do
    use_synth :growl
    play 70, pan: -1
    sleep 0.1
    play 75, pan: 0
    sleep 0.1
    play 80, pan: 1
    sleep 0.1
  end
end
11.times do
  use_synth :piano
  play 50
  sleep 0.5
  play 65
  play 50
  sleep 0.5
  play 65
  sleep 0.5
end



use_synth :piano
play :G4
sleep 0.5
play :G3
sleep 0.5
play :G4
play :G3
sleep 0.5
play :G4
play :G3
sleep 0.3
play :D4, release: 3
play :G4, release: 5
sleep 0.3
play :A4
sleep 0.3
play :B4
sleep 0.3
play :A4
play :D3
sleep 0.3
play :A3, release: 3
play :A4, release: 5


in_thread do
  play :A4
  sleep 0.3
  play :B4
  sleep 0.3
  play :C5
  sleep 0.3
  play :B4
  sleep 0.7
  play :B4, release: 2
  sleep 0.3
  play :A4
  sleep 0.3
  play :G4
  sleep 0.3
  play :B4
  sleep 0.3
  play :A4
  sleep 0.3
  play :G4
  sleep 0.3
  play :B4
  sleep 0.3
  play :C5
  sleep 0.3
  play :A4
  sleep 0.3
  play :B4
  sleep 1
  play :B4
  sleep 0.3
  play :C5
  sleep 0.3
  play :D5
  sleep 0.3
  play :A4
  sleep 0.7
  play :A4
  sleep 0.1
  play :A4
  sleep 0.3
  play :B4
  sleep 0.3
  play :C5
  sleep 0.3
  play :B4
  sleep 0.6
  play :B4
  sleep 0.1
  play :B4
  sleep 0.3
  play :A4
  sleep 0.3
  play :G4
  sleep 0.3
  play :C5
  sleep 0.3
  play :B4
  sleep 0.6
  play :B4
  sleep 0.1
  play :B4
  sleep 0.3
  play :A4
  sleep 0.3
  play :G4
  sleep 0.3
  play :B4
  sleep 0.3
  play :A4
  sleep 0.3
  play :G4
  sleep 1
end
play :D4, release: 3
sleep 1
play :E3
sleep 0.3
play :B3, release: 2
sleep 0.3
play :E4, release: 6
sleep 0.3
play :C3
sleep 0.3
play :G3, release: 3
sleep 0.3
play :C4, release: 6
sleep 0.3
play :G3
sleep 0.3
play :D4, release: 5
sleep 2
play :D3
sleep 0.3
play :A3, release: 5
sleep 0.3
play :D4, release: 6
sleep 0.3
play :E3
sleep 0.3
play :B3
sleep 0.3
play :E4
sleep 0.3
play :D4
sleep 0.3
play :E3
sleep 0.3
play :B3
sleep 0.3
play :E4
sleep 2
play :C3
sleep 0.3
play :G3
sleep 0.7
play :C4
sleep 0.3
play :G3
sleep 0.3
play :D4
sleep 0.3
play :G4
sleep 1



use_synth :piano
play 65
play 50
sleep 1
play 65
sleep 1
6.times do
  play :C, amp: 0.5
  sleep 0.45
  play :D, amp: 0.5
  sleep 0.45
end
4.times do
  play :B
  play :G
  play :D
  sleep 1
end
4.times do
  play :B
  play :G
  play :E
  sleep 1
end
4.times do
  play :C
  play :G
  play :E
  sleep 1
end
4.times do
  play :B
  play :G
  play :D
  sleep 1
end
play :B3
sleep 1
play :G3
sleep 1
play :E3
sleep 1
2.times do
  play :B
  play :G
  play :E
  sleep 1
end
2.times do
  play :E
  play :G
  play :C
  sleep 1
end
2.times do
  play :B
  play :G
  play :D
  sleep 1
end
2.times do
  play :D
  play :A
  sleep 1
end

